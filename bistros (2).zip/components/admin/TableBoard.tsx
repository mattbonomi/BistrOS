import React, { useEffect, useState } from 'react';
import { Table, Order } from '../../types';
import { backend } from '../../services/mockBackend';
import { Users, Clock, AlertCircle, CheckCircle, DollarSign, Archive, Loader2 } from 'lucide-react';
import { MENU_ITEMS } from '../../constants'; // Fallback for names

interface TableBoardProps {
    tables: Table[];
}

const MiniOrderView: React.FC<{ orderId: string }> = ({ orderId }) => {
    const [order, setOrder] = useState<Order | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let mounted = true;
        backend.getOrder(orderId).then(o => {
            if (mounted && o) setOrder(o);
            setLoading(false);
        });
        return () => { mounted = false; };
    }, [orderId]);

    if (loading) return <Loader2 size={16} className="animate-spin text-gray-400 mt-2" />;
    if (!order) return null;

    return (
        <div className="mt-2 text-xs bg-white/60 p-2 rounded border border-black/5">
            {order.items.map((item, idx) => {
                const prod = MENU_ITEMS.find(p => p.id === item.productId);
                return (
                    <div key={idx} className="flex justify-between">
                        <span>{item.quantity}x {prod?.name}</span>
                    </div>
                );
            })}
            <div className="mt-1 font-bold pt-1 border-t border-black/10">
                Total: ${order.total.toLocaleString()}
            </div>
        </div>
    );
};

export const TableBoard: React.FC<TableBoardProps> = ({ tables }) => {
    
    const markPreparation = (orderId: string | null) => {
        if(orderId) backend.setOrderState(orderId, 'EN_PREPARACION');
    };

    const attendWaiter = (tableId: string) => backend.attendWaiter(tableId);
    const deliverBill = (tableId: string) => backend.deliverBill(tableId);
    const closeTable = (tableId: string) => backend.closeTable(tableId);

    const getCardStyle = (table: Table) => {
        switch (table.status) {
            case 'LIBRE': return 'bg-gray-50 border-gray-100 text-gray-400 opacity-70 hover:opacity-100';
            case 'ABIERTA': return 'bg-blue-50 border-blue-200 text-blue-900';
            case 'PENDIENTE': return 'bg-red-50 border-red-500 text-red-900 ring-1 ring-red-400 shadow-md';
            case 'OCUPADA': return 'bg-green-50 border-green-300 text-green-900';
            case 'PAGADA': return 'bg-purple-50 border-purple-300 text-purple-900';
            default: return 'bg-white';
        }
    };

    const formatTime = (ts: number | null) => {
        if (!ts) return '';
        const diff = Math.floor((Date.now() - ts) / 60000);
        return `${diff} min`;
    };

    return (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {tables.map(table => (
                <div key={table.id} className={`border-2 rounded-xl p-4 flex flex-col justify-between min-h-[200px] shadow-sm relative transition-all duration-300 ${getCardStyle(table)}`}>
                    
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-2xl font-bold">#{table.id}</span>
                        {table.status !== 'LIBRE' && (
                             <div className="flex items-center space-x-1 text-xs font-mono bg-white/60 px-2 py-1 rounded">
                                <Users size={12} />
                                <span>{table.connectedDevices}</span>
                            </div>
                        )}
                    </div>

                    <div className="flex-1">
                        <div className="text-xs font-bold uppercase tracking-wider mb-2 opacity-70">
                            {table.status}
                        </div>

                        {table.status === 'ABIERTA' && (
                            <div className="text-sm opacity-80">
                                Escaneado hace {formatTime(table.openedAt)}
                            </div>
                        )}

                        {table.status === 'PENDIENTE' && (
                            <div className="animate-pulse-slow">
                                <div className="flex items-center font-bold text-red-700 mb-2">
                                    <AlertCircle size={16} className="mr-1" />
                                    {table.pendingReason === 'PRODUCTOS' && 'PEDIDO NUEVO'}
                                    {table.pendingReason === 'CAMARERO' && 'LLAMA CAMARERO'}
                                    {table.pendingReason === 'CUENTA' && 'PIDE CUENTA'}
                                </div>
                                <div className="text-xs flex items-center mb-2 font-medium">
                                    <Clock size={12} className="mr-1" />
                                    Hace {formatTime(table.lastEventAt)}
                                </div>

                                {table.pendingReason === 'PRODUCTOS' && table.currentOrderId && (
                                    <MiniOrderView orderId={table.currentOrderId} />
                                )}
                            </div>
                        )}

                        {table.status === 'OCUPADA' && (
                            <div>
                                <div className="text-sm mb-2 font-medium">En servicio (Saludable)</div>
                                {table.currentOrderId && <MiniOrderView orderId={table.currentOrderId} />}
                            </div>
                        )}

                         {table.status === 'PAGADA' && (
                            <div>
                                <div className="flex items-center text-sm font-bold text-purple-700 mb-2">
                                    <CheckCircle size={16} className="mr-1"/> Pago Confirmado
                                </div>
                                <div className="text-xs opacity-70">Listo para liberar mesa.</div>
                            </div>
                        )}
                    </div>

                    <div className="mt-4 pt-4 border-t border-black/5 space-y-2">
                        {table.status === 'PENDIENTE' && table.pendingReason === 'PRODUCTOS' && (
                            <button 
                                onClick={() => markPreparation(table.currentOrderId)}
                                className="w-full bg-red-600 text-white py-2 rounded font-bold text-sm hover:bg-red-700 shadow-sm"
                            >
                                MARCAR EN PREPARACIÓN
                            </button>
                        )}
                        {table.status === 'PENDIENTE' && table.pendingReason === 'CAMARERO' && (
                            <button 
                                onClick={() => attendWaiter(table.id)}
                                className="w-full bg-blue-600 text-white py-2 rounded font-bold text-sm hover:bg-blue-700 shadow-sm"
                            >
                                ATENDER
                            </button>
                        )}
                        {table.status === 'PENDIENTE' && table.pendingReason === 'CUENTA' && (
                            <button 
                                onClick={() => deliverBill(table.id)}
                                className="w-full bg-green-600 text-white py-2 rounded font-bold text-sm hover:bg-green-700 shadow-sm"
                            >
                                LLEVAR CUENTA
                            </button>
                        )}

                        {table.status === 'OCUPADA' && (
                            <button 
                                onClick={() => closeTable(table.id)}
                                className="w-full bg-white border-2 border-green-600 text-green-700 py-2 rounded font-bold text-sm hover:bg-green-50 flex items-center justify-center transition-colors"
                            >
                                <DollarSign size={16} className="mr-1" /> COBRAR Y LIBERAR
                            </button>
                        )}
                        
                        {table.status === 'PAGADA' && (
                             <button 
                                onClick={() => closeTable(table.id)}
                                className="w-full bg-purple-600 text-white py-2 rounded font-bold text-sm hover:bg-purple-700 flex items-center justify-center shadow-sm"
                            >
                                <Archive size={16} className="mr-2" /> LIBERAR MESA
                            </button>
                        )}
                    </div>
                </div>
            ))}
        </div>
    );
};
