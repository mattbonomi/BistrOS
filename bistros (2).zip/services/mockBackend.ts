import { DashboardMetrics, Order, Table, OrderState, Product } from '../types';
import { DEFAULT_MENU_ITEMS } from '../constants';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';
const WS_BASE_URL = process.env.REACT_APP_WS_URL || 'ws://localhost:3000';

class BistrOSService {
  private ws: WebSocket | null = null;
  private tableListeners: Map<string, Array<(table: Table) => void>> = new Map();
  private managerListeners: Array<() => void> = [];
  private reconnectInterval: any = null;

  constructor() {
    this.connectWebSocket();
  }

  // --- WEBSOCKET CONNECTION ---

  private connectWebSocket() {
    // Prevent multiple connections
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return;

    try {
        this.ws = new WebSocket(WS_BASE_URL);

        this.ws.onopen = () => {
            console.log('Connected to BistrOS realtime server');
            if (this.reconnectInterval) {
                clearInterval(this.reconnectInterval);
                this.reconnectInterval = null;
            }
        };

        this.ws.onmessage = (event) => {
            try {
                const message = JSON.parse(event.data);
                this.handleSocketMessage(message);
            } catch (e) {
                console.error('Error parsing WS message', e);
            }
        };

        this.ws.onclose = () => {
            console.log('Disconnected from BistrOS server. Reconnecting...');
            this.scheduleReconnect();
        };

        this.ws.onerror = (err) => {
            console.error('WS Error', err);
            this.ws?.close();
        };
    } catch (e) {
        console.error('WS Connection failed', e);
        this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
      if (!this.reconnectInterval) {
          this.reconnectInterval = setInterval(() => this.connectWebSocket(), 5000);
      }
  }

  private handleSocketMessage(message: any) {
      if (message.type === 'TABLE_UPDATE') {
          const tableId = message.payload.id;
          const listeners = this.tableListeners.get(tableId);
          if (listeners) {
              listeners.forEach(cb => cb(message.payload));
          }
          // Also notify manager
          this.managerListeners.forEach(cb => cb());
      } else if (message.type === 'GLOBAL_UPDATE') {
          this.managerListeners.forEach(cb => cb());
      }
  }

  // --- REST API METHODS ---

  private async fetchJson<T>(endpoint: string, options?: RequestInit): Promise<T> {
      try {
          const res = await fetch(`${API_BASE_URL}${endpoint}`, {
              ...options,
              headers: {
                  'Content-Type': 'application/json',
                  ...options?.headers,
              },
          });
          if (!res.ok) throw new Error(`API Error: ${res.statusText}`);
          return await res.json();
      } catch (e) {
          console.error(`Fetch error for ${endpoint}:`, e);
          throw e;
      }
  }

  // --- CLIENT ENDPOINTS ---

  public async scanQR(tableId: string): Promise<Table> {
      return this.fetchJson<Table>(`/tables/${tableId}/scan`, { method: 'POST' });
  }

  public async getMenu(): Promise<Product[]> {
      try {
          return await this.fetchJson<Product[]>('/menu');
      } catch (e) {
          console.warn('Failed to fetch menu, using default fallback');
          return DEFAULT_MENU_ITEMS;
      }
  }

  public updateCart(tableId: string, productId: string, delta: number) {
      // Optimistic update should be handled in UI, this just fires and forgets
      this.fetchJson(`/tables/${tableId}/cart`, {
          method: 'POST',
          body: JSON.stringify({ productId, delta })
      }).catch(console.error);
  }

  public async placeOrder(tableId: string): Promise<Order | null> {
      return this.fetchJson<Order>('/orders', {
          method: 'POST',
          body: JSON.stringify({ tableId })
      });
  }

  public requestWaiter(tableId: string) {
      this.fetchJson(`/tables/${tableId}/waiter`, { method: 'POST' }).catch(console.error);
  }

  public requestBill(tableId: string, paymentMethod?: string) {
      this.fetchJson(`/tables/${tableId}/bill`, { 
          method: 'POST',
          body: JSON.stringify({ paymentMethod })
      }).catch(console.error);
  }

  public payTable(tableId: string, method: string, amount: number) {
      this.fetchJson(`/tables/${tableId}/pay`, {
          method: 'POST',
          body: JSON.stringify({ method, amount })
      }).catch(console.error);
  }

  public async getTableOrders(tableId: string): Promise<Order[]> {
      try {
        return await this.fetchJson<Order[]>(`/tables/${tableId}/orders`);
      } catch (e) {
        return [];
      }
  }

  // --- MANAGER ENDPOINTS ---

  public async getTables(): Promise<Table[]> {
      try {
        return await this.fetchJson<Table[]>('/tables');
      } catch (e) {
        return [];
      }
  }

  public async getOrder(orderId: string): Promise<Order | undefined> {
      try {
          return await this.fetchJson<Order>(`/orders/${orderId}`);
      } catch(e) {
          return undefined;
      }
  }

  public async getAllOrders(): Promise<Order[]> {
      try {
        return await this.fetchJson<Order[]>('/orders');
      } catch (e) {
        return [];
      }
  }

  public setOrderState(orderId: string, newState: OrderState) {
      this.fetchJson(`/orders/${orderId}/state`, {
          method: 'POST',
          body: JSON.stringify({ state: newState })
      }).catch(console.error);
  }

  public attendWaiter(tableId: string) {
      this.fetchJson(`/tables/${tableId}/attend`, { method: 'POST' }).catch(console.error);
  }

  public deliverBill(tableId: string) {
      this.fetchJson(`/tables/${tableId}/deliver-bill`, { method: 'POST' }).catch(console.error);
  }

  public closeTable(tableId: string) {
      this.fetchJson(`/tables/${tableId}/close`, { method: 'POST' }).catch(console.error);
  }

  public async getDashboardMetrics(): Promise<DashboardMetrics | null> {
      try {
          return await this.fetchJson<DashboardMetrics>('/dashboard/metrics');
      } catch (e) {
          console.error("Metrics unavailable");
          return null;
      }
  }

  // --- SUBSCRIPTIONS ---

  public subscribeToTable(tableId: string, cb: (table: Table) => void) {
      if (!this.tableListeners.has(tableId)) {
          this.tableListeners.set(tableId, []);
      }
      this.tableListeners.get(tableId)!.push(cb);
      
      // Initial fetch to ensure data
      this.fetchJson<Table>(`/tables/${tableId}`).then(cb).catch(console.error);

      return () => {
          const list = this.tableListeners.get(tableId) || [];
          this.tableListeners.set(tableId, list.filter(l => l !== cb));
      };
  }

  public subscribeManager(cb: () => void) {
      this.managerListeners.push(cb);
      return () => {
          this.managerListeners = this.managerListeners.filter(l => l !== cb);
      };
  }
}

export const backend = new BistrOSService();
