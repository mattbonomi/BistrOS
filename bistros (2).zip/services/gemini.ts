import { GoogleGenAI } from "@google/genai";
import { DEFAULT_MENU_ITEMS } from '../constants';
import { DashboardMetrics } from '../types';

const apiKey = process.env.API_KEY || ''; // Must be configured in build/env
const ai = new GoogleGenAI({ apiKey });

export const GeminiService = {
  
  /**
   * AI Waiter Logic
   * Answers questions about the menu.
   */
  async askWaiter(question: string): Promise<string> {
    if (!apiKey) return "Lo siento, mi cerebro de IA no está configurado actualmente.";

    const menuContext = DEFAULT_MENU_ITEMS.map(item => `${item.name} ($${item.price}): ${item.description || item.category}`).join('\n');
    
    const prompt = `
      You are a friendly and knowledgeable waiter at BistrOS.
      Here is the menu:
      ${menuContext}

      Answer the customer's question concisely and persuasively. If they ask for recommendations, suggest items from the menu.
      Customer: "${question}"
    `;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });
      return response.text || "Disculpa, no entendí bien la pregunta.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Hubo un problema de conexión con la cocina (IA).";
    }
  },

  /**
   * AI Manager Analyst
   * Analyzes dashboard metrics to provide insights.
   */
  async analyzeMetrics(metrics: DashboardMetrics): Promise<string> {
    if (!apiKey) return "Análisis de IA no disponible (Falta API Key).";

    const dataSummary = JSON.stringify({
        totalSessions: metrics.totalSessions,
        conversion: metrics.conversionRate,
        abandonment: metrics.abandonedCartsRate,
        salesWeather: metrics.salesByWeather,
        topProducts: metrics.popularProducts.slice(0, 3),
        deadProducts: metrics.deadProducts
    });

    const prompt = `
      Act as a Senior Restaurant Manager. Analyze these daily metrics for BistrOS:
      ${dataSummary}

      Provide a 3-bullet point executive summary with specific actionable advice to improve revenue or efficiency tomorrow.
      Keep it professional and concise (Spanish).
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text || "No se pudo generar el análisis.";
    } catch (error) {
        return "Error al contactar al analista virtual.";
    }
  }
};
